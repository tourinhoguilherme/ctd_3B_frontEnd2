function somar(x, y) {
  return x + y
}

export default { somar }
