function multiplicar(x, y) {
  return x * y
}

export default { multiplicar }
