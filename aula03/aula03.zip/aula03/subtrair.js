function subtrair(x, y) {
  return x - y
}

export default { subtrair }
