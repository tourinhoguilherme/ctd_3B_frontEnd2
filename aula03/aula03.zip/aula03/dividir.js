function dividir(x, y) {
  return x / y
}

export default { dividir }
